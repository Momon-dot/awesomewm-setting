#!/bin/bash

ram_val=$(free | grep Mem | awk '{printf "%.1f\n", $3/$2 * 100.0}')

echo "🚃 $ram_val%"