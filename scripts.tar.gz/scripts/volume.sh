#!/bin/bash

default_sink=$(pactl info | grep "Default Sink" | awk '/Default Sink:/ {print $3}')
volume_level=$(pactl list sinks | grep -A 7 "Name: $default_sink" | tail -n 1 | awk '/Volume:/{printf $5}' | tr -d "%")
mute_status=$(pactl list sinks | grep -A 6 "Name: $default_sink" | tail -n 1 | awk '/Mute:/{printf $2}')

if [ $mute_status == "yes" ]; then
    echo 🔇
elif [[ $volume_level -ge 99 ]]; then
    echo "📢 $volume_level%"
elif [[ $volume_level -lt 40 ]]; then
    echo "🔈 $volume_level%"
elif [[ $volume_level -lt 70 ]]; then
    echo "🔉 $volume_level%"
else 
    echo "🔊 $volume_level%"
fi