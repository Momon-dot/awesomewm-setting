#!/bin/bash

wifi_output=$(nmcli device show wlp7s0)
wifi_state=$(echo "$wifi_output" | awk '/GENERAL.STATE:/{printf $3}') 
if [ $wifi_state == '(connecting' ];then
    echo '⏳'
elif [ $wifi_state == '(connected)' ];then
    echo "📶"
else
    echo "🚫🌐"
fi