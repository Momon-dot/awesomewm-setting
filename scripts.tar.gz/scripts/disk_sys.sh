

disk_usage_1=$(df /dev/nvme0n1p7 | awk '/nvme0n1p7/{printf $5}')
disk_usage_2=$(df /dev/sda2 | awk '/sda2/{printf $5}')



echo "📏 $disk_usage_1 💽 $disk_usage_2"