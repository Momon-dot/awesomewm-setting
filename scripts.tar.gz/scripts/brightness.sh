#!/bin/bash

brightness_val=$(brightnessctl g)
brightness_level=$(($brightness_val * 100 / 24000))

if [[ $brightness_level -lt 25 ]] ;then
    echo "🌙 $brightness_level"
elif [[ $brightness_level -lt 50 ]] ;then
    echo "🔅 $brightness_level"
elif [[ $brightness_level -lt 75 ]] ;then
    echo "🔆 $brightness_level"    
else
    echo "🌞 $brightness_level" 
fi