#!/bin/bash

battery_state=$(upower -i /org/freedesktop/UPower/devices/battery_BAT0)
bat_percent=$(echo "$battery_state" | awk '/percentage:/ {printf $2}' | tr -d '%')
bat_state=$(echo "$battery_state" | awk '/state:/ {printf $2}')


if [ $bat_state == "charging" ];then
    batt_state="🔺"
elif [ $bat_state == "fully-charged" ];then
    batt_state="⚡︎"
else
    batt_state="🔻"
fi

if [[ $bat_percent > 20 ]];then
    batt_charge="🔋"
else
    batt_charge="🪫"
fi
echo $batt_charge
echo $batt_state
echo $bat_percent
cat ~/.config/awesome/scripts/battery/flag.txt