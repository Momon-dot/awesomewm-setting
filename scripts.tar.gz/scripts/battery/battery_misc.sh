#!/bin/bash

#!/bin/bash


# Use sed to replace the first line in the file
sed -i "1s/.*/$1/" ~/.config/awesome/scripts/battery/flag.txt