#!/bin/bash
wifi_output=$(nmcli device show wlp7s0)
wifi_state=$(echo "$wifi_output" | awk '/GENERAL.STATE:/{printf $3}') 
if [ $wifi_state == '(connecting' ];then
    echo 'Connecting...'
elif [ $wifi_state == '(connected)' ];then
    wifi_name=$(echo "$wifi_output" | awk -F 'GENERAL.CONNECTION:' '{printf $2}') 
    wifi_IPv4=$(echo "$wifi_output" | awk '/IP4.ADDRESS/{printf $2}') 
    wifi_IPv4_gw=$(echo "$wifi_output" | awk '/IP4.GATEWAY/{printf $2}') 
    wifi_IPv6=$(echo "$wifi_output" | awk '/IP6.ADDRESS/{printf $2}') 


    echo $wifi_name
    echo $wifi_IPv4
    echo $wifi_IPv4_gw
    echo $wifi_IPv6
else
    echo "Not Connected"
fi