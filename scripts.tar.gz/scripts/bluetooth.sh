#!/bin/bash

bt_hw_info=$(bluetoothctl show | awk '/Powered:/{printf $2}')

if [[ $bt_hw_info == "yes" ]];then
    device_count=0
    bt_info=$(bluetoothctl devices | cut -f2 -d' ' | while read uuid; do bluetoothctl info $uuid; done|grep -e "Connected\|Name")
    while IFS= read -r line1 && IFS= read -r line2; do
        # Do something with the two lines, for example, print them
    
        if [[ $(echo $line2 | awk '/Connected:/{printf $2}') == "yes" ]];then
        device_count=$(( $device_count + 1 ))
        fi

    done <<< "$bt_info"

    echo " "$device_count
else
    echo " ✖️"
fi

