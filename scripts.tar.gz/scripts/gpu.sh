#!/bin/bash

# Extract memory usage and total memory from NVIDIA-SMI output
memory_info=$(nvidia-smi --query-gpu=memory.used,memory.total --format=csv,noheader,nounits, | awk '{printf "%.1f\n", $1/$2 * 100.0}')
memory_used=$(echo "$memory_info" | awk -F', ' '{print $1}')
memory_total=$(echo "$memory_info" | awk -F', ' '{print $2}')

echo "🎮 $memory_info%"
